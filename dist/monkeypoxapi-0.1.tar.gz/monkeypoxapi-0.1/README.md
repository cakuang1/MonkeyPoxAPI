# MonkeyPoxAPI


reject monke, return to humanity

Webscraped data from CDC's website. 